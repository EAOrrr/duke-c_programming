printf "%s\n%s\n%s\n" "This is a sample test case" "it checks your program's one argument behavior" "go!" | tee | ./sortLines
