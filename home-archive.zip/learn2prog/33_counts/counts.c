#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "counts.h"
counts_t * createCounts(void) {
  //WRITE ME
  counts_t *newc = malloc(sizeof(*newc));
  newc->numOfOne = 0;
  newc->numOfUn = 0;
  newc->one_count = NULL;
  return newc;
}
void addCount(counts_t * c, const char * name) {
  //WRITE ME
  if(name == NULL){
    c->numOfUn++;
    return;
  }
  for(int i = 0; i < c->numOfOne; i++){
    if(!strcmp(c->one_count[i].str, name)){
      c->one_count[i].counts++;
      return;
    }
  }
  int n = c->numOfOne;
  c->numOfOne++;
  c->one_count = realloc(c->one_count, (n+1)*sizeof(*c->one_count));
  c->one_count[n].counts = 1;
  c->one_count[n].str = malloc(sizeof(char)*(strlen(name)+1));
  strcpy(c->one_count[n].str, name);
}
void printCounts(counts_t * c, FILE * outFile) {
  //WRITE ME
  for(int i = 0; i < c->numOfOne; i++){
    fprintf(outFile, "%s: %d\n", c->one_count[i].str, c->one_count[i].counts);
  }
  if(c->numOfUn)
    fprintf(outFile, "<unknown> : %d\n", c->numOfUn);
}

void freeCounts(counts_t * c) {
  //WRITE ME
  for(int i = 0; i < c->numOfOne; i++){
    free(c->one_count[i].str);
  }
  if(c->numOfOne){
    free(c->one_count);
  }
  free(c);
}
