#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <ctype.h>
#include <string.h>
#include "cards.h"
#include "deck.h"
#include "eval.h"
#include "future.h"
#include "input.h"

void MonteCarlo_trial(deck_t **hands, size_t n_hands,
		      long long *win_count, long long times,
		      deck_t *rem_deck, future_cards_t * fc){
  while(times--){
    shuffle(rem_deck);
    future_cards_from_deck(rem_deck, fc);
    size_t win = 0;
    int tie = 0;
    for(size_t i = 1; i < n_hands; i++){
      if(compare_hands(hands[win], hands[i]) == 0)
	tie = 1;
      else if(compare_hands(hands[win], hands[i]) < 0){
	win = i;
	tie = 0;
      }
    }
    if(tie){
      win_count[n_hands]++;
    }
    else{
      win_count[win]++;
    }
  }
}

int main(int argc, char ** argv) {
  //YOUR CODE GOES HERE
  if(argc < 2){
    fprintf(stderr, "Too few argument\n");
    return EXIT_FAILURE;
  }
  if(argc > 3){
    fprintf(stderr, "too many arguments");
    return EXIT_FAILURE;
  }
  long long T = 10000;
  if(argc == 3){
    T = atoll(argv[2]);
  }
  FILE*f = fopen(argv[1], "r");
  if(f == NULL){
    perror("could not open the file\n");
    return EXIT_FAILURE;
  }
  size_t n_hands;
  future_cards_t *fc = malloc(sizeof(*fc));
  fc->n_decks = 0;
  fc->decks = NULL;
  deck_t ** hands =read_input(f, &n_hands, fc);
  if(n_hands == 0){
    fprintf(stderr, "No input hands\n");
    return EXIT_FAILURE;
  }
  deck_t *rem_deck = build_remaining_deck(hands, n_hands);
  long long win_count[n_hands+1];
  memset(win_count, 0, sizeof(win_count));
  MonteCarlo_trial(hands, n_hands, win_count, T, rem_deck, fc);
  for(size_t i = 0; i <n_hands; i++){
    printf("Hand %zu won %llu / %llu times(%.2f%%)\n", i, win_count[i], T, 100*win_count[i]/(double)T);
  }
  printf("And there were %llu ties\n", win_count[n_hands]);
  for(size_t i = 0; i < n_hands; i++){
    free_deck(hands[i]);
  }
  free(hands);
  free_deck(rem_deck);
  for(size_t i = 0; i < fc->n_decks; i++){
    free(fc->decks[i].cards);
  }
  free(fc->decks);
  free(fc);
  if(fclose(f) != 0){
    perror("Failed to close the file\n");
    return EXIT_FAILURE;
  }
  
  return EXIT_SUCCESS;
}
