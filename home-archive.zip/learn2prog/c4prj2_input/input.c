#include<string.h>
#include<stdlib.h>
#include<ctype.h>
#include"input.h"
#include"cards.h"

deck_t ** read_input(FILE*f, size_t * n_hands, future_cards_t *fc){
  deck_t **hands = NULL;
  char*line = NULL;
  size_t sz;
  *n_hands = 0;
  while(getline(&line, &sz, f) >0 ){
    (*n_hands)++;
    hands = realloc(hands, sizeof(*hands) * (*n_hands));
    hands[*(n_hands)-1] = hand_from_string(line, fc);
  }
  free(line);
  return hands;
}

deck_t *hand_from_string(const char *str, future_cards_t *fc){
  deck_t *d = malloc(sizeof(*d));
  d->cards = NULL;
  d->n_cards = 0;
  char *copy = malloc(sizeof(*copy) * (strlen(str)+1));
  strcpy(copy, str);
  char delim[2] = " ";
  char *token;
  token = strtok(copy, delim);
  while(token != NULL){
    d->cards = realloc(d->cards, sizeof(*d->cards) * d->n_cards);
    if(token[0] == '?'){
      card_t *unknown = add_empty_card(d);
      int num = 0, i = 1;
      while(isdigit(token[i])){
	  num = num*10 + token[i]-'0';
	  i++;
	}
      add_future_card(fc, num, unknown);
    }
    else if (token[0]!='\n'){
      add_card_to(d, card_from_letters(token[0], token[1]));
    }
    token = strtok(NULL, delim);
  }
  free(copy);
  if(d->n_cards < 5){
      fprintf(stderr, "hands with cards less than 5");
      exit(EXIT_FAILURE);
    }
  return d;
}
