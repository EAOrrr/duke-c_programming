#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "kv.h"

void removen(char *line){
  char*p = strchr(line, '\n');
  if(p == NULL){
    fprintf(stderr, "Invalid Input");
    exit(EXIT_FAILURE);
  }
  *p = '\0';
}

kvarray_t * readin(FILE *f){
  kvarray_t *kv = malloc(sizeof(*kv));
  kv->kvarray = NULL;
  char *line = NULL, *copy = NULL;
  size_t sz;
  int n = 0;
  while(getline(&line, &sz, f) > 0){
    copy = malloc(sz);
    strcpy(copy, line);
    
    kv->numOfKv = ++n;
    kv->kvarray = realloc(kv->kvarray, kv->numOfKv * sizeof(*kv->kvarray));

    removen(copy);

    char *ptr = strchr(copy, '=');
    if(ptr == NULL){
      fprintf(stderr, "Invalid input");
      exit(EXIT_FAILURE);
    }
    kv->kvarray[n-1].value = malloc(sizeof(char) *(strlen(ptr)+1));
    strcpy(kv->kvarray[n-1].value, ptr+1);
    *ptr = '\0';

    kv->kvarray[n-1].key = malloc(sizeof(char)*(strlen(copy)+1));
    strcpy(kv->kvarray[n-1].key, copy);

    free(copy);
  }
  free(line);
  if(n)
    return kv;
  free(kv);
  return NULL;
}

kvarray_t * readKVs(const char * fname) {
  //WRITE ME
  FILE *f = fopen(fname, "r");
  if(f == NULL){
    perror("Could not open theFile");
    exit(EXIT_FAILURE);
  }

  kvarray_t*kv = readin(f);

  if(fclose(f) != 0){
    perror("Failed to close the file");
    exit(EXIT_FAILURE);
}
  return kv;
}

void freeKVs(kvarray_t * pairs) {
  //WRITE ME
  if(pairs == NULL) return;
  for(int i = 0; i < pairs->numOfKv; i++){
    free(pairs->kvarray[i].key);
    free(pairs->kvarray[i].value);
}
  free(pairs->kvarray);
  free(pairs);
}

void printKVs(kvarray_t * pairs) {
  //WRITE ME
  if(pairs == NULL) return;
  for(int i = 0; i < pairs->numOfKv; i++){
    printf("key = '%s' value = '%s'\n", pairs->kvarray[i].key, pairs->kvarray[i].value);
  }
}

char * lookupValue(kvarray_t * pairs, const char * key) {
  //WRITE ME
  if(pairs == NULL) return NULL;
  for(int i = 0; i < pairs->numOfKv; i++){
    if(!strcmp(key, pairs->kvarray[i].key)){
      return pairs->kvarray[i].value;
    }
  }
  return NULL;
}
