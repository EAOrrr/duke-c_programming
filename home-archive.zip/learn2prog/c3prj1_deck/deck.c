#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "deck.h"
void print_hand(deck_t * hand){
  for(int i = 0; i < hand->n_cards; i++){
    print_card(*(hand->cards)[i]);
    printf(" ");
  }
}

int deck_contains(deck_t * d, card_t c) {
  for(int i = 0; i < d->n_cards; i++){
    if((*(d->cards)[i]).value == c.value && (*(d->cards[i])).suit == c.suit)
      return 1;
  }
  return 0;
}

void shuffle(deck_t * d){
  int c = 0;
  while(c< 52){
    for(int n = c+7>d->n_cards?d->n_cards:c+7; n > 0; n--){
      int random = rand()%n;
      card_t temp = *(d->cards)[n-1];
      *(d->cards)[n-1] = *(d->cards)[random];
      *(d->cards)[random] = temp;
    }
    c+=5;
  }
}

void assert_full_deck(deck_t * d) {
  for(int i = 0; i < 52; i++){
    card_t c = card_from_num(i);
    assert(deck_contains(d,c));
  }
}

void add_card_to(deck_t *deck, card_t c){
  deck->n_cards++;
  int n = deck->n_cards;
  deck->cards = realloc(deck->cards, sizeof(*deck->cards) *n);
  (deck->cards)[n-1] = malloc(sizeof(card_t));
  *(deck->cards)[n-1] = c;
}

card_t * add_empty_card(deck_t *deck){
  card_t c;
  c.suit =0;
  c.value = 0;
  deck-> n_cards++;
  int n = deck->n_cards;
  deck->cards = realloc(deck->cards, sizeof(*deck->cards) * n);
  (deck->cards)[n-1] = malloc(sizeof(card_t));
  *(deck->cards)[n-1] = c;
  return (deck->cards)[n-1];
}

deck_t * make_new_deck(){
  deck_t * d = malloc(sizeof(*d));
  d->n_cards = 0;
  d->cards = NULL;
  return d;
}

deck_t *make_deck_exclude(deck_t* excluded_cards){
  deck_t *d = make_new_deck();
  for(size_t i = 0; i < 52; i++){
    card_t c = card_from_num(i);
    if(!deck_contains(excluded_cards, c)){
      add_card_to(d, c);
    }
  }
  return d;
}

void free_deck(deck_t *deck){
  for(int i = 0; i < deck->n_cards; i++){
    free((deck->cards)[i]);
  }
  free(deck->cards);
  free(deck);
}

deck_t * build_remaining_deck(deck_t **hands, size_t n_hands){
  deck_t *d1 = make_new_deck(), *d2;
  for(size_t i = 0; i < n_hands; i++){
    for(size_t j = 0; j < hands[i]->n_cards; j++){
      card_t c = *(hands[i]->cards)[j];
      if(!deck_contains(d1, c)){
	add_card_to(d1, c);
      }
    }
  }
  d2 = make_deck_exclude(d1);
  free_deck(d1);
  return d2;
}
